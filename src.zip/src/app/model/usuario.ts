export class Usuario {
  lng: any;
  lat: any;
    id: string;
    nome: string;
    email: string;
    pws: string;
    quant: number;
    data: number;
    valor: number;
    ativo: boolean = true;
    foto: string ;
    opcões: string;
}
