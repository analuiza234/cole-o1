// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.



  export const environment = {
    production: true,
     firebaseConfig : {
      apiKey: "AIzaSyDuCg-Hu4r9NoCXTUzRfDz12g4tSviDMKc",
      authDomain: "collections1-3209b.firebaseapp.com",
      databaseURL: "https://collections1-3209b.firebaseio.com",
      projectId: "collections1-3209b",
      storageBucket: "collections1-3209b.appspot.com",
      messagingSenderId: "739737717926",
      appId: "1:739737717926:web:a98933fbba7725b7003867",
      measurementId: "G-B07S2L6207"
    }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
